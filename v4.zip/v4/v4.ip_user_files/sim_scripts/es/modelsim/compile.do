vlib modelsim_lib/work
vlib modelsim_lib/msim

vlib modelsim_lib/msim/xilinx_vip
vlib modelsim_lib/msim/axi_infrastructure_v1_1_0
vlib modelsim_lib/msim/axi_vip_v1_1_8
vlib modelsim_lib/msim/processing_system7_vip_v1_0_10
vlib modelsim_lib/msim/xil_defaultlib

vmap xilinx_vip modelsim_lib/msim/xilinx_vip
vmap axi_infrastructure_v1_1_0 modelsim_lib/msim/axi_infrastructure_v1_1_0
vmap axi_vip_v1_1_8 modelsim_lib/msim/axi_vip_v1_1_8
vmap processing_system7_vip_v1_0_10 modelsim_lib/msim/processing_system7_vip_v1_0_10
vmap xil_defaultlib modelsim_lib/msim/xil_defaultlib

vlog -work xilinx_vip -64 -incr -sv -L axi_vip_v1_1_8 -L processing_system7_vip_v1_0_10 -L xilinx_vip "+incdir+/home/leon/Xilinx/Vivado/2020.2/data/xilinx_vip/include" \
"/home/leon/Xilinx/Vivado/2020.2/data/xilinx_vip/hdl/axi4stream_vip_axi4streampc.sv" \
"/home/leon/Xilinx/Vivado/2020.2/data/xilinx_vip/hdl/axi_vip_axi4pc.sv" \
"/home/leon/Xilinx/Vivado/2020.2/data/xilinx_vip/hdl/xil_common_vip_pkg.sv" \
"/home/leon/Xilinx/Vivado/2020.2/data/xilinx_vip/hdl/axi4stream_vip_pkg.sv" \
"/home/leon/Xilinx/Vivado/2020.2/data/xilinx_vip/hdl/axi_vip_pkg.sv" \
"/home/leon/Xilinx/Vivado/2020.2/data/xilinx_vip/hdl/axi4stream_vip_if.sv" \
"/home/leon/Xilinx/Vivado/2020.2/data/xilinx_vip/hdl/axi_vip_if.sv" \
"/home/leon/Xilinx/Vivado/2020.2/data/xilinx_vip/hdl/clk_vip_if.sv" \
"/home/leon/Xilinx/Vivado/2020.2/data/xilinx_vip/hdl/rst_vip_if.sv" \

vlog -work axi_infrastructure_v1_1_0 -64 -incr "+incdir+../../../../v4.gen/sources_1/bd/es/ipshared/ec67/hdl" "+incdir+../../../../v4.gen/sources_1/bd/es/ipshared/34f8/hdl" "+incdir+/home/leon/Xilinx/Vivado/2020.2/data/xilinx_vip/include" \
"../../../../v4.gen/sources_1/bd/es/ipshared/ec67/hdl/axi_infrastructure_v1_1_vl_rfs.v" \

vlog -work axi_vip_v1_1_8 -64 -incr -sv -L axi_vip_v1_1_8 -L processing_system7_vip_v1_0_10 -L xilinx_vip "+incdir+../../../../v4.gen/sources_1/bd/es/ipshared/ec67/hdl" "+incdir+../../../../v4.gen/sources_1/bd/es/ipshared/34f8/hdl" "+incdir+/home/leon/Xilinx/Vivado/2020.2/data/xilinx_vip/include" \
"../../../../v4.gen/sources_1/bd/es/ipshared/94c3/hdl/axi_vip_v1_1_vl_rfs.sv" \

vlog -work processing_system7_vip_v1_0_10 -64 -incr -sv -L axi_vip_v1_1_8 -L processing_system7_vip_v1_0_10 -L xilinx_vip "+incdir+../../../../v4.gen/sources_1/bd/es/ipshared/ec67/hdl" "+incdir+../../../../v4.gen/sources_1/bd/es/ipshared/34f8/hdl" "+incdir+/home/leon/Xilinx/Vivado/2020.2/data/xilinx_vip/include" \
"../../../../v4.gen/sources_1/bd/es/ipshared/34f8/hdl/processing_system7_vip_v1_0_vl_rfs.sv" \

vlog -work xil_defaultlib -64 -incr "+incdir+../../../../v4.gen/sources_1/bd/es/ipshared/ec67/hdl" "+incdir+../../../../v4.gen/sources_1/bd/es/ipshared/34f8/hdl" "+incdir+/home/leon/Xilinx/Vivado/2020.2/data/xilinx_vip/include" \
"../../../bd/es/ip/es_processing_system7_0_1/sim/es_processing_system7_0_1.v" \

vcom -work xil_defaultlib -64 -93 \
"../../../bd/es/ipshared/96fb/led_blinker.vhd" \
"../../../bd/es/ip/es_led_blinker_0_0/sim/es_led_blinker_0_0.vhd" \
"../../../bd/es/sim/es.vhd" \

vlog -work xil_defaultlib \
"glbl.v"

